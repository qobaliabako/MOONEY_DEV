declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    RESEARCH_OWNER_EMAIL?: string;
  }
}
