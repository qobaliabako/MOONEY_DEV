// Streaming ZIP (STORE method, UTF-8 names, data descriptors). Keeps only each
// chunk and the small central directory in memory, not the whole research archive.
const encode=(s:string)=>new TextEncoder().encode(s);
const table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crcUpdate(crc:number,chunk:Uint8Array){for(const b of chunk)crc=table[(crc^b)&255]^(crc>>>8);return crc;}
function header(length:number,values:[number,number,number][]){const a=new Uint8Array(length),v=new DataView(a.buffer);for(const [at,size,n]of values)size===2?v.setUint16(at,n,true):v.setUint32(at,n,true);return a;}
export type ZipEntry={name:string,chunks:AsyncIterable<string|Uint8Array>};
export async function* zip(entries:AsyncIterable<ZipEntry>){
 let offset=0;const directory:Uint8Array[]=[];let count=0;
 for await(const entry of entries){
  const name=encode(entry.name),start=offset;
  const local=header(30,[[0,4,0x04034b50],[4,2,20],[6,2,0x808],[12,2,33],[26,2,name.length]]);
  yield local;yield name;offset+=local.length+name.length;let crc=0xffffffff,size=0;
  for await(const value of entry.chunks){const chunk=typeof value==='string'?encode(value):value;size+=chunk.length;crc=crcUpdate(crc,chunk);yield chunk;offset+=chunk.length;}
  if(size>0xffffffff||offset>0xffffffff||count>=65535)throw Error('Archive exceeds ZIP limits');
  crc=(crc^0xffffffff)>>>0;const descriptor=header(16,[[0,4,0x08074b50],[4,4,crc],[8,4,size],[12,4,size]]);yield descriptor;offset+=16;
  directory.push(header(46,[[0,4,0x02014b50],[4,2,20],[6,2,20],[8,2,0x808],[14,2,33],[16,4,crc],[20,4,size],[24,4,size],[28,2,name.length],[42,4,start]]),name);count++;
 }
 const centralOffset=offset;for(const chunk of directory){yield chunk;offset+=chunk.length;}
 yield header(22,[[0,4,0x06054b50],[8,2,count],[10,2,count],[12,4,offset-centralOffset],[16,4,centralOffset]]);
}
export function zipStream(entries:AsyncIterable<ZipEntry>){const it=zip(entries);return new ReadableStream<Uint8Array>({async pull(controller){try{const r=await it.next();if(r.done)controller.close();else controller.enqueue(r.value);}catch(error){controller.error(error);}},async cancel(){await it.return(undefined);}});}
