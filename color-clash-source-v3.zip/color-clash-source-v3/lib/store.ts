import { env } from 'cloudflare:workers';
export function database(){if(!env.DB)throw Error('Research storage unavailable');return env.DB;}
export function isResearchOwner(userId:string|null|undefined,email:string|null|undefined){return !!userId&&!!env.RESEARCH_OWNER_EMAIL&&email?.trim().toLowerCase()===env.RESEARCH_OWNER_EMAIL.trim().toLowerCase();}
// These headers are set by Sites dispatch, never by application form inputs.
export function researcher(request:Request){return isResearchOwner(request.headers.get('oai-authenticated-user-id'),request.headers.get('oai-authenticated-user-email'));}
export async function hash(text:string){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join('');}
export function reply(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
export function sameOrigin(request:Request){return request.headers.get('origin')===new URL(request.url).origin;}
export async function body(request:Request){if(Number(request.headers.get('content-length'))>200000)throw Error('Request too large');const text=await request.text();if(text.length>200000)throw Error('Request too large');return JSON.parse(text);}
