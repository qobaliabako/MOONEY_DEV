import {database,hash} from './store';
import {makeTask,makePractice,isResearch,score,summarize,type Mode,type ResponseRow,type Trial} from './task';
export type Session={id:string,client_id:string,token_hash:string,mode:Mode,ordinal:number,seed:number,version:string,knowledge:string,status:string,metadata:string,survey:string|null,demographics:string|null,summary:string|null,saved:number,started:string,updated:string};
export async function authorize(id:string,token:string){
 if(!/^(research|research_check|demo|experiment)_P\d{3,}$/.test(id)||!/^[a-f0-9]{64}$/.test(token))throw Error('Unauthorized session');
 const s=await database().prepare('SELECT * FROM sessions WHERE id = ?').bind(id).first<Session>();
 if(!s&&await database().prepare('SELECT id FROM deleted_sessions WHERE id = ?').bind(id).first())throw Error('Session permanently deleted');
 if(!s||s.token_hash!==await hash(token))throw Error('Unauthorized session');return s;
}
export async function storedRows(id:string){const r=await database().prepare('SELECT payload FROM trials WHERE session_id = ? ORDER BY seq').bind(id).all<{payload:string}>();return r.results.map(r=>JSON.parse(r.payload) as ResponseRow);}
export async function schedules(s:Session){const practice=await Promise.all([makePractice(s.mode,s.seed,1),makePractice(s.mode,s.seed,2)]);return {practice,task:makeTask(s.mode,s.seed)};}
export function expectedNext(previous:ResponseRow[],practice:Trial[][],task:Trial[]){
 for(const block of practice){const used=previous.filter(r=>r.phase==='practice'&&r.block===block[0].block);if(used.length<block.length)return block[used.length];if(used.reduce((a,r)=>a+r.rt_usable,0)/block.length>=.8){const measured=previous.filter(r=>r.phase==='task');return task[measured.length]??null;}}
 return null;
}
export function normalize(input:Record<string,unknown>,expected:Trial,seq:number,mode:Mode){
 if(input.seq!==seq||input.trial_id!==expected.trial_id)throw Error('Out-of-order trial');
 for(const [k,v] of Object.entries(expected))if(input[k]!==v)throw Error('Trial differs from assigned schedule');
 const key=input.response_key,rt=input.rt_s;
 if(typeof key!=='string'||!(rt===null||typeof rt==='number')||(!['d','f','j',...(isResearch(mode)?[]:['k']),''].includes(key)))throw Error('Invalid key');
 const timing:Record<string,number>={};
 for(const k of ['onset_s','offset_s','frame_interval_count','long_frame_count','max_frame_interval_s','visibility_interrupted','fullscreen_lost','viewport_changed','held_key_wait_s','synthetic_event_count']){
  const v=input[k];if(typeof v!=='number'||!Number.isFinite(v)||v<0)throw Error('Invalid timing');timing[k]=v;
 }
 if(timing.offset_s<timing.onset_s||timing.long_frame_count>timing.frame_interval_count||timing.frame_interval_count<1)throw Error('Invalid frame timing');
 return {...expected,seq,...score(expected,key,rt),...timing} as ResponseRow;
}
export async function append(s:Session,inputs:Record<string,unknown>[]){
 const old=await storedRows(s.id),all=[...old];const plan=await schedules(s);const commands=[];
 for(const input of inputs){
  if(!Number.isInteger(input.seq)||Number(input.seq)<0||Number(input.seq)>600)throw Error('Invalid sequence');
  if(Number(input.seq)<old.length){const normalized=normalize(input,old[Number(input.seq)],Number(input.seq),s.mode);if(JSON.stringify(normalized)!==JSON.stringify(old[Number(input.seq)]))throw Error('Conflicting retry');continue;}
  if(s.status!=='running')throw Error('Session no longer running');
  const expected=expectedNext(all,plan.practice,plan.task);if(!expected)throw Error('No next trial is permitted');
  const row=normalize(input,expected,all.length,s.mode);
  if(all.length&&row.onset_s<=all[all.length-1].offset_s)throw Error('Nonchronological response');
  all.push(row);const payload=JSON.stringify(row);
  commands.push(database().prepare('INSERT INTO trials (session_id, seq, trial_id, payload, hash) VALUES (?, ?, ?, ?, ?) ON CONFLICT(session_id,seq) DO NOTHING').bind(s.id,row.seq,row.trial_id,payload,await hash(payload)));
 }
 if(commands.length){commands.push(database().prepare('UPDATE sessions SET saved = (SELECT COUNT(*) FROM trials WHERE session_id = ?), updated = ? WHERE id = ?').bind(s.id,new Date().toISOString(),s.id));await database().batch(commands);}
 const persisted=await storedRows(s.id);
 for(const row of all)if(JSON.stringify(persisted[row.seq])!==JSON.stringify(row))throw Error('Conflicting concurrent upload');
 return persisted.length;
}
export async function finish(s:Session,status:string){
 if(s.status==='withdrawn')throw Error('Session withdrawn');
 const rows=await storedRows(s.id);const summary=summarize(rows,s.mode);
 if(status==='completed'&&!summary.task_completed)throw Error('All measured trials must be acknowledged before completion');
 if(status==='practice_failed'){const plan=await schedules(s);if(expectedNext(rows,plan.practice,plan.task)!==null||summary.task_completed)throw Error('Practice failure not established');}
 // A timed task that is already complete remains complete if final questions are skipped.
 const final=summary.task_completed?'completed':status;
 await database().prepare('UPDATE sessions SET status = ?, summary = ?, updated = ? WHERE id = ? AND status != ?').bind(final,JSON.stringify(summary),new Date().toISOString(),s.id,'withdrawn').run();
 return {status:final,summary};
}
