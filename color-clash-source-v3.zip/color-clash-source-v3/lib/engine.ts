'use client';
import {KEYS,RGB,score,type Trial,type ResponseRow} from './task';
export class Interrupted extends Error{}
const frame=()=>new Promise<number>(resolve=>requestAnimationFrame(resolve));
export async function estimateRefresh(){const times=[];let last=await frame();for(let i=0;i<90;i++){const now=await frame();if(i>=20)times.push(now-last);last=now;}const a=[...times].sort((a,b)=>a-b),period=a[Math.floor(a.length/2)];return {period,hz:1000/period,stable:times.filter(v=>Math.abs(v-period)<2).length/times.length>.9};}
export class Engine{
 held=new Set<string>();handler:((e:KeyboardEvent)=>void)|null=null;stopped=false;stopReason='aborted';controller=new AbortController();synthetic=0;
 width:number;height:number;ratio:number;ctx:CanvasRenderingContext2D;
 constructor(public canvas:HTMLCanvasElement,public period:number,public keys:string[],public fullscreen:boolean){
  this.width=innerWidth;this.height=innerHeight;this.ratio=devicePixelRatio;canvas.width=Math.round(this.width*this.ratio);canvas.height=Math.round(this.height*this.ratio);canvas.style.width=this.width+'px';canvas.style.height=this.height+'px';this.ctx=canvas.getContext('2d',{alpha:false})!;this.ctx.scale(this.ratio,this.ratio);
  const opts={signal:this.controller.signal};
  window.addEventListener('keydown',e=>{if(!e.isTrusted){this.synthetic++;return;}const key=e.key.toLowerCase();if(key==='escape'){this.stop('aborted');return;}if(this.keys.includes(key)){e.preventDefault();this.held.add(key);if(!e.repeat&&!e.altKey&&!e.ctrlKey&&!e.metaKey)this.handler?.(e);}},opts);
  window.addEventListener('keyup',e=>this.held.delete(e.key.toLowerCase()),opts);
  window.addEventListener('blur',()=>this.stop('interrupted'),opts);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)this.stop('interrupted');},opts);
  document.addEventListener('fullscreenchange',()=>{if(this.fullscreen&&!document.fullscreenElement)this.stop('interrupted');},opts);
  window.addEventListener('resize',()=>{if(innerWidth!==this.width||innerHeight!==this.height)this.stop('interrupted');},opts);
 }
 stop(reason:string){this.stopped=true;this.stopReason=reason;}
 check(){if(this.stopped)throw new Interrupted(this.stopReason);}
 cleanup(){this.controller.abort();this.handler=null;}
 clear(){this.ctx.fillStyle='#14181f';this.ctx.fillRect(0,0,this.width,this.height);}
 text(text:string,y=this.height/2,size=.04*this.height,colour='#e5eaf2'){this.ctx.font=`${size}px Arial`;this.ctx.fillStyle=colour;this.ctx.textAlign='center';this.ctx.textBaseline='middle';this.ctx.fillText(text,this.width/2,y);}
 legend(){this.text(this.keys.map(k=>`${k.toUpperCase()} = ${Object.keys(KEYS).find(c=>KEYS[c]===k)!.toUpperCase()}`).join('     '),this.height*.86,this.height*.027);}
 async fixed(ms:number,draw:()=>void){this.check();await frame();draw();const n=Math.max(1,Math.round(ms/this.period));for(let i=0;i<n;i++){await frame();this.check();}}
 async waitKey(expected:string){while(this.held.size){await frame();this.check();}return new Promise<void>((resolve,reject)=>{this.handler=e=>{if(e.key.toLowerCase()===expected){this.handler=null;resolve();}};const check=()=>{if(this.stopped){this.handler=null;reject(new Interrupted(this.stopReason));}else if(this.handler)requestAnimationFrame(check);};requestAnimationFrame(check);});}
 async trial(t:Trial,seq:number,practice:boolean):Promise<ResponseRow>{
  const holdStart=performance.now();while(this.held.size){await frame();this.check();}const heldWait=(performance.now()-holdStart)/1000;
  await this.fixed(500,()=>{this.clear();this.text('+',this.height/2,this.height*.06);if(practice)this.legend();});
  this.check();const onset=await frame();this.clear();
  if(t.frame){this.ctx.strokeStyle='rgb(170,180,195)';this.ctx.lineWidth=2;this.ctx.beginPath();if(t.frame==='circle')this.ctx.arc(this.width/2,this.height/2,.25*this.height,0,Math.PI*2);else this.ctx.rect(this.width/2-.325*this.height,this.height/2-.2*this.height,.65*this.height,.4*this.height);this.ctx.stroke();}
  this.ctx.font=`bold ${this.height*.085}px Arial`;this.ctx.fillStyle=RGB[t.ink_color];this.ctx.textAlign='center';this.ctx.textBaseline='middle';this.ctx.fillText(t.text,this.width/2,this.height/2);if(practice)this.legend();
  let response:{key:string,rt:number}|null=null;let previous=onset,count=0,long=0,max=0;
  this.handler=e=>{let ts=e.timeStamp;if(ts>1e12)ts-=performance.timeOrigin;const rt=(ts-onset)/1000;if(response===null&&rt>=0&&rt<=3)response={key:e.key.toLowerCase(),rt};};
  let offset=onset;
  try{while(true){offset=await frame();this.check();const interval=offset-previous;count++;max=Math.max(max,interval);if(interval>1.5*this.period)long++;previous=offset;if(response!==null||offset-onset>=3000)break;}}
  finally{this.handler=null;this.clear();}
  const answer=response as {key:string,rt:number}|null;
  return {...t,seq,...score(t,answer?.key??'',answer?.rt??null),onset_s:onset/1000,offset_s:offset/1000,frame_interval_count:count,long_frame_count:long,max_frame_interval_s:max/1000,visibility_interrupted:0,fullscreen_lost:0,viewport_changed:0,held_key_wait_s:heldWait,synthetic_event_count:this.synthetic};
 }
 async after(row:ResponseRow,practice:boolean){if(practice)await this.fixed(700,()=>{this.clear();this.text(row.anticipatory?'Wait until the coloured text appears.':row.correct?'Correct ink colour.':row.timeout?`No response in time. ${row.ink_color.toUpperCase()} = ${row.correct_key.toUpperCase()}`:`Ink colour: ${row.ink_color.toUpperCase()} = ${row.correct_key.toUpperCase()}`,this.height/2,this.height*.038);this.legend();});await this.fixed(400,()=>{this.clear();if(practice)this.legend();});}
}
