import {database} from './store';
import {schedules,storedRows,type Session} from './session';

export type Analysis={excluded_from_analysis:boolean,exclusion_reason:string|null,exclusion_changed_at:string|null};
export type AnalysisEvent={excluded_from_analysis:boolean,reason:string,changed_at:string};
export type ResearchRow={id:string,mode:string,version:string,knowledge:string,status:string,started:string,updated:string,saved:number,metadata:string,demographics:string|null,summary:string|null,survey_saved:number}&Analysis&{exclusion_history:AnalysisEvent[]};
export const SESSION_ID=/^(research|research_check|demo|experiment)_P\d{3,}$/;
const safeColumns='id,mode,ordinal,seed,version,knowledge,status,started,updated,saved,metadata,survey,demographics,summary';
export async function analysis(id:string):Promise<Analysis&{exclusion_history:AnalysisEvent[]}>{
 const db=database();
 const [current,history]=await Promise.all([
  db.prepare('SELECT excluded,reason,changed_at FROM session_analysis WHERE session_id = ?').bind(id).first<{excluded:number,reason:string,changed_at:string}>(),
  db.prepare('SELECT excluded,reason,changed_at FROM exclusion_history WHERE session_id = ? ORDER BY sequence').bind(id).all<{excluded:number,reason:string,changed_at:string}>()
 ]);
 return {excluded_from_analysis:!!current?.excluded,exclusion_reason:current?.reason??null,exclusion_changed_at:current?.changed_at??null,exclusion_history:history.results.map(r=>({excluded_from_analysis:!!r.excluded,reason:r.reason,changed_at:r.changed_at}))};
}
export async function listSessions(){
 const db=database();
 const result=await db.prepare(`SELECT ${safeColumns} FROM sessions ORDER BY started DESC LIMIT 500`).all<Session>();
 const count=await db.prepare('SELECT COUNT(*) AS total FROM sessions').first<{total:number}>();
 const histories=(await db.prepare('SELECT session_id,excluded,reason,changed_at FROM exclusion_history ORDER BY sequence').all<{session_id:string,excluded:number,reason:string,changed_at:string}>()).results;
 const current=(await db.prepare('SELECT session_id,excluded,reason,changed_at FROM session_analysis').all<{session_id:string,excluded:number,reason:string,changed_at:string}>()).results;
 const sessions:ResearchRow[]=result.results.map(s=>{const a=current.find(a=>a.session_id===s.id);return {id:s.id,mode:s.mode,version:s.version,knowledge:s.knowledge,status:s.status,started:s.started,updated:s.updated,saved:s.saved,metadata:s.metadata,demographics:s.demographics,summary:s.summary,survey_saved:s.survey?1:0,excluded_from_analysis:!!a?.excluded,exclusion_reason:a?.reason??null,exclusion_changed_at:a?.changed_at??null,exclusion_history:histories.filter(h=>h.session_id===s.id).map(h=>({excluded_from_analysis:!!h.excluded,reason:h.reason,changed_at:h.changed_at}))};});
 return {sessions,total:count?.total??0};
}
// Explicit research-field projections: credentials and bookkeeping never enter exports.
function pick(value:unknown,keys:string[]):Record<string,unknown>{const o=value&&typeof value==='object'?value as Record<string,unknown>:{};return Object.fromEntries(keys.filter(k=>Object.hasOwn(o,k)).map(k=>[k,o[k]]));}
const trialFields='trial_id phase block trial_in_block condition word text ink_color correct_key trial epoch cue cue_set context frame frequent_colour is_frequent colour_repeat cue_repeat context_switch seq response_key rt_s correct timeout anticipatory rt_usable onset_s offset_s frame_interval_count long_frame_count max_frame_interval_s visibility_interrupted fullscreen_lost viewport_changed held_key_wait_s synthetic_event_count'.split(' ');
const metadataFields='user_agent width height pixel_ratio refresh_hz refresh_stable fullscreen time_origin consent adult_confirmed english_instructions_understood data_kind timing_method physical_timing_calibrated nationality_collected'.split(' ');
export async function researchRecord(id:string){
 const s=await database().prepare(`SELECT ${safeColumns} FROM sessions WHERE id = ?`).bind(id).first<Session>();
 if(!s)return null;
 return buildRecord(s,await storedRows(id),await analysis(id));
}
async function buildRecord(s:Session,rows:unknown[],state:Analysis&{exclusion_history:AnalysisEvent[]}){
 const rawSummary=s.summary?JSON.parse(s.summary):null;
 const summary:Record<string,unknown>|null=rawSummary?{...pick(rawSummary,['mode','version','n_task','task_completed','accuracy_percent','spillover_ms','interpretation']),cells:(rawSummary.cells??[]).map((c:unknown)=>pick(c,['context','epoch','condition','n_presented','n_rt_usable','median_correct_rt_ms'])),benefits:pick(rawSummary.benefits,['A_pre','A_post','B_pre','B_post'])}:null;
 const plan=s.status==='withdrawn'?{task:[],practice:[]}:await schedules(s);
 return {id:s.id,mode:s.mode,ordinal:s.ordinal,seed:s.seed,version:s.version,knowledge:s.knowledge,status:s.status,started:s.started,updated:s.updated,saved:s.saved,metadata:pick(JSON.parse(s.metadata),metadataFields),survey:s.survey?JSON.parse(s.survey).map((r:unknown)=>pick(r,['question','answer','cue','context','frame'])):null,demographics:s.demographics?pick(JSON.parse(s.demographics),['age_group','gender']):null,summary,...state,planned_task:plan.task,planned_practice:plan.practice,trials:rows.map(r=>pick(r,trialFields))};
}
export type ResearchRecord=NonNullable<Awaited<ReturnType<typeof researchRecord>>>;
export const contextFields=['session_id','mode','app_version','seed','data_kind','prior_task_knowledge','session_status','demographics_submitted','age_group','gender','excluded_from_analysis','exclusion_reason','exclusion_changed_at'];
export const trialCsvFields=[...contextFields,...trialFields];
export const summaryCsvFields=[...contextFields,'ordinal','started','updated','saved_rows','questionnaire_saved','n_task','task_completed','accuracy_percent','spillover_ms','summary_json','questionnaire_json','demographics_json','exclusion_history_json'];
function context(s:ResearchRecord){return {session_id:s.id,mode:s.mode,app_version:s.version,seed:s.seed,data_kind:s.metadata.data_kind,prior_task_knowledge:s.knowledge,session_status:s.status,demographics_submitted:s.demographics?1:0,age_group:s.demographics?.age_group,gender:s.demographics?.gender,excluded_from_analysis:s.excluded_from_analysis?1:0,exclusion_reason:s.exclusion_reason,exclusion_changed_at:s.exclusion_changed_at};}
export function summaryRow(s:ResearchRecord){return {...context(s),ordinal:s.ordinal,started:s.started,updated:s.updated,saved_rows:s.saved,questionnaire_saved:s.survey?1:0,n_task:s.summary?.n_task,task_completed:s.summary?.task_completed,accuracy_percent:s.summary?.accuracy_percent,spillover_ms:s.summary?.spillover_ms,summary_json:s.summary,questionnaire_json:s.survey,demographics_json:s.demographics,exclusion_history_json:s.exclusion_history};}
export function trialRows(s:ResearchRecord){return s.trials.map(r=>({...context(s),...r}));}
export function csvLine(fields:string[],row?:Record<string,unknown>){return fields.map(f=>{const v=row?row[f]:f;let text=v==null?'':typeof v==='object'?JSON.stringify(v):String(v);if(typeof v==='string'&&/^[\s]*[=+\-@\t\r]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';}).join(',')+'\r\n';}

export async function deleteSessions(ids:string[]){
 const db=database(),now=new Date().toISOString();
 // A single D1 transaction records tombstones and removes all research records.
 await db.batch(ids.flatMap(id=>[
  db.prepare('INSERT INTO deleted_sessions (id,client_id,deleted_at) SELECT id,client_id,? FROM sessions WHERE id = ? ON CONFLICT(id) DO NOTHING').bind(now,id),
  db.prepare('DELETE FROM trials WHERE session_id = ?').bind(id),
  db.prepare('DELETE FROM exclusion_history WHERE session_id = ?').bind(id),
  db.prepare('DELETE FROM session_analysis WHERE session_id = ?').bind(id),
  db.prepare('DELETE FROM sessions WHERE id = ?').bind(id)
 ]));
}
export async function setExclusion(ids:string[],excluded:boolean,reason:string){
 const db=database(),now=new Date().toISOString();
 await db.batch(ids.flatMap(id=>[
  // Also serves as a foreign-key guard: a concurrently deleted session rolls back the whole batch.
  db.prepare('INSERT INTO exclusion_history (session_id,excluded,reason,changed_at) VALUES (?,?,?,?)').bind(id,+excluded,reason,now),
  db.prepare('INSERT INTO session_analysis (session_id,excluded,reason,changed_at) VALUES (?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET excluded=excluded.excluded,reason=excluded.reason,changed_at=excluded.changed_at').bind(id,+excluded,reason,now)
 ]));
}

// Bound each read to 40 sessions to keep large exports within Worker memory
// and database-call limits, while exporting beyond the dashboard's 500 rows.
export async function* allResearchRecords(ids:string[]){
 const db=database();
 for(let start=0;start<ids.length;start+=40){
  const page=ids.slice(start,start+40),marks=page.map(()=>'?').join(',');
  const [sessions,rows,states,history]=await db.batch<Record<string,unknown>>([
   db.prepare(`SELECT ${safeColumns} FROM sessions WHERE id IN (${marks}) ORDER BY started,id`).bind(...page),
   db.prepare(`SELECT session_id,payload FROM trials WHERE session_id IN (${marks}) ORDER BY session_id,seq`).bind(...page),
   db.prepare(`SELECT session_id,excluded,reason,changed_at FROM session_analysis WHERE session_id IN (${marks})`).bind(...page),
   db.prepare(`SELECT session_id,excluded,reason,changed_at FROM exclusion_history WHERE session_id IN (${marks}) ORDER BY sequence`).bind(...page)
  ]);
  for(const value of sessions.results){const s=value as unknown as Session,a=states.results.find(a=>a.session_id===s.id);yield await buildRecord(s,rows.results.filter(r=>r.session_id===s.id).map(r=>JSON.parse(String(r.payload))),{excluded_from_analysis:!!a?.excluded,exclusion_reason:a?.reason as string??null,exclusion_changed_at:a?.changed_at as string??null,exclusion_history:history.results.filter(h=>h.session_id===s.id).map(h=>({excluded_from_analysis:!!h.excluded,reason:String(h.reason),changed_at:String(h.changed_at)}))});}
 }
}
