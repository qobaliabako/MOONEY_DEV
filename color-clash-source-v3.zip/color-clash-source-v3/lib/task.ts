/** Python-compatible MT19937 shuffles preserve the desktop schedules. */
export const VERSION='0.4.1-web';
export const MODES=['research','research_check','demo','experiment'] as const;
export type Mode=typeof MODES[number];
export const CUES=['DAXI','FENU','GOPA','HESI','JONU','KAVO'];
export const COLOURS=['red','blue','green'];
export const KEYS:Record<string,string>={red:'d',blue:'f',green:'j',yellow:'k'};
export const RGB:Record<string,string>={red:'rgb(239,91,91)',blue:'rgb(80,155,255)',green:'rgb(95,205,120)',yellow:'rgb(240,207,75)'};
export type Trial={trial_id:string,phase:string,block:number,trial_in_block:number,condition:string,word:string,text:string,ink_color:string,correct_key:string,trial?:number,epoch?:string,cue?:string,cue_set?:string,context?:string,frame?:string,frequent_colour?:string,is_frequent?:number,colour_repeat?:number,cue_repeat?:number,context_switch?:number};
export type ResponseRow=Trial & {seq:number,response_key:string,rt_s:number|null,correct:number,timeout:number,anticipatory:number,rt_usable:number,onset_s:number,offset_s:number,frame_interval_count:number,long_frame_count:number,max_frame_interval_s:number,visibility_interrupted:number,fullscreen_lost:number,viewport_changed:number,held_key_wait_s:number,synthetic_event_count:number};
export class PyRandom{
 mt=new Uint32Array(624);index=624;
 constructor(seed:number|bigint){
  const keys:number[]=[];let n=BigInt(seed);do{keys.push(Number(n&0xffffffffn));n>>=32n;}while(n);
  this.mt[0]=19650218;for(let i=1;i<624;i++)this.mt[i]=(Math.imul(1812433253,this.mt[i-1]^(this.mt[i-1]>>>30))+i)>>>0;
  let i=1,j=0;for(let k=Math.max(624,keys.length);k>0;k--){this.mt[i]=((this.mt[i]^Math.imul(this.mt[i-1]^(this.mt[i-1]>>>30),1664525))+keys[j]+j)>>>0;if(++i>=624){this.mt[0]=this.mt[623];i=1;}if(++j>=keys.length)j=0;}
  for(let k=623;k>0;k--){this.mt[i]=((this.mt[i]^Math.imul(this.mt[i-1]^(this.mt[i-1]>>>30),1566083941))-i)>>>0;if(++i>=624){this.mt[0]=this.mt[623];i=1;}}
  this.mt[0]=0x80000000;
 }
 next(){if(this.index>=624){for(let i=0;i<624;i++){const y=(this.mt[i]&0x80000000)|(this.mt[(i+1)%624]&0x7fffffff);this.mt[i]=(this.mt[(i+397)%624]^(y>>>1)^((y&1)?0x9908b0df:0))>>>0;}this.index=0;}let y=this.mt[this.index++];y^=y>>>11;y^=(y<<7)&0x9d2c5680;y^=(y<<15)&0xefc60000;y^=y>>>18;return y>>>0;}
 below(n:number){const bits=Math.floor(Math.log2(n))+1;let v;do{v=this.next()>>>(32-bits);}while(v>=n);return v;}
 shuffle<T>(a:T[]){for(let i=a.length-1;i>0;i--){const j=this.below(i+1);[a[i],a[j]]=[a[j],a[i]];}return a;}
}
async function stringRandom(text:string){const bytes=new TextEncoder().encode(text);const digest=new Uint8Array(await crypto.subtle.digest('SHA-512',bytes));let n=0n;for(const b of [...bytes,...digest])n=(n<<8n)|BigInt(b);return new PyRandom(n);}
export function isMode(value:unknown):value is Mode{return typeof value==='string'&&(MODES as readonly string[]).includes(value);}
export function isResearch(mode:Mode){return mode==='research'||mode==='research_check';}
export function makeTask(mode:Mode,seed:number):Trial[]{
 if(!isMode(mode)||!Number.isInteger(seed)||seed<0||seed>=2**32)throw Error('Invalid mode or seed');
 const rng=new PyRandom(seed);
 if(!isResearch(mode)){const rows:Trial[]=[];for(let block=1;block<=(mode==='experiment'?2:1);block++)rows.push(...classicBlock(rng,'task',block,mode==='experiment'?3:1,4));return rows;}
 const cues=rng.shuffle([...CUES]),base:Record<string,string>={};for(const start of [0,3]){const colours=rng.shuffle([...COLOURS]);cues.slice(start,start+3).forEach((c,i)=>base[c]=colours[i]);}
 const changed=new Set(cues.slice(3)),shift=[1,2][rng.below(2)],fa=['circle','rectangle'][rng.below(2)],fb=fa==='circle'?'rectangle':'circle';
 const rows:Trial[]=[];
 for(let chunk=0;chunk<4;chunk++){
  const slots:Trial[]=[];
  for(const cue of cues)for(const context of ['A','B']){
   const offset=chunk>=2&&changed.has(cue)&&context==='A'?shift:0;
   const frequent=COLOURS[(COLOURS.indexOf(base[cue])+offset)%3];
   for(const initial of [...Array(8).fill(base[cue]),...COLOURS.filter(c=>c!==base[cue])]){
    const colour=COLOURS[(COLOURS.indexOf(initial)+offset)%3],f=colour===frequent;
    slots.push({trial_id:'',phase:'task',block:chunk+1,trial_in_block:0,condition:f?'frequent':'infrequent',word:cue,text:cue,ink_color:colour,correct_key:KEYS[colour],epoch:chunk<2?'pre':'post',cue,cue_set:changed.has(cue)?'changeable':'unchanged',context,frame:context==='A'?fa:fb,frequent_colour:frequent,is_frequent:+f});
   }
  }rows.push(...rng.shuffle(slots));
 }
 rows.forEach((r,i)=>{r.trial=i+1;r.trial_id=`task-t${String(i+1).padStart(3,'0')}`;r.trial_in_block=i%120+1;r.colour_repeat=+(i>0&&r.ink_color===rows[i-1].ink_color);r.cue_repeat=+(i>0&&r.cue===rows[i-1].cue);r.context_switch=+(i>0&&r.context!==rows[i-1].context);});
 return mode==='research_check'?rows.slice(0,24):rows;
}
function classicBlock(rng:PyRandom,phase:string,block:number,repeats:number,neutral:number){
 const rows:Trial[]=[];const colours=[...COLOURS,'yellow'];
 for(const word of colours)for(const ink of colours)for(let i=0;i<repeats;i++)rows.push({trial_id:'',phase,block,trial_in_block:0,condition:word===ink?'congruent':'incongruent',word:word.toUpperCase(),text:word.toUpperCase(),ink_color:ink,correct_key:KEYS[ink]});
 for(const ink of colours)for(let i=0;i<neutral;i++)rows.push({trial_id:'',phase,block,trial_in_block:0,condition:'neutral',word:'',text:'XXXX',ink_color:ink,correct_key:KEYS[ink]});
 return rng.shuffle(rows).map((r,i)=>({...r,trial_id:`${phase}-b${block}-t${String(i+1).padStart(3,'0')}`,trial_in_block:i+1}));
}
export async function makePractice(mode:Mode,seed:number,attempt:number){
 const rng=await stringRandom(`color-clash-${isResearch(mode)?'research-':''}practice-${seed}-${attempt}`);
 if(!isResearch(mode))return classicBlock(rng,'practice',attempt,1,2);
 const rows:Trial[]=[];for(const cue of ['NEVA','PIMO','TULU'])for(const ink of COLOURS)for(const frame of ['circle','rectangle'])for(let i=0;i<2;i++)rows.push({trial_id:'',phase:'practice',block:attempt,trial_in_block:0,condition:'practice',word:cue,text:cue,ink_color:ink,correct_key:KEYS[ink],epoch:'practice',cue,cue_set:'practice',context:'practice',frame,frequent_colour:'',is_frequent:0,colour_repeat:0,cue_repeat:0,context_switch:0});
 return rng.shuffle(rows).map((r,i)=>({...r,trial:i+1,trial_id:`practice-a${attempt}-t${String(i+1).padStart(3,'0')}`,trial_in_block:i+1}));
}
export function score(t:Trial,key:string,rt:number|null){const timeout=key===''&&rt===null;if(!timeout&&(!Object.values(KEYS).includes(key)||rt===null||!Number.isFinite(rt)||rt<0||rt>3))throw Error('Invalid response');const correct=+(!timeout&&key===t.correct_key),anticipatory=+(!timeout&&rt!==null&&rt<.2);return {response_key:key,rt_s:rt,correct,timeout:+timeout,anticipatory,rt_usable:+(!!correct&&!anticipatory)};}
function median(x:number[]){if(!x.length)return null;const a=[...x].sort((a,b)=>a-b);const m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;}
export function summarize(rows:ResponseRow[],mode:Mode){
 const task=rows.filter(r=>r.phase==='task');const complete=task.length===makeTask(mode,0).length;
 const cells=[];const benefits:Record<string,number|null>={};
 if(isResearch(mode))for(const context of ['A','B'])for(const epoch of ['pre','post']){
  const medians=[];
  for(const condition of ['frequent','infrequent']){const cell=task.filter(r=>r.cue_set==='unchanged'&&r.context===context&&r.epoch===epoch&&r.condition===condition),rt=cell.filter(r=>r.rt_usable).map(r=>1000*r.rt_s!);const med=median(rt);medians.push(med);cells.push({context,epoch,condition,n_presented:cell.length,n_rt_usable:rt.length,median_correct_rt_ms:med});}
  benefits[context+'_'+epoch]=medians.every(v=>v!==null)?medians[1]!-medians[0]!:null;
 }
 const b=benefits;const spillover=mode==='research'&&complete&&Object.values(b).every(v=>v!==null)?(b.A_post!-b.A_pre!)-(b.B_post!-b.B_pre!):null;
 return {mode,version:VERSION,n_task:task.length,task_completed:complete,accuracy_percent:task.length?100*task.reduce((a,r)=>a+r.correct,0)/task.length:null,cells,benefits,spillover_ms:spillover,interpretation:'One session; descriptive only. Browser timing is not physically calibrated. Informed/repeat sessions cannot establish incidental learning.'};
}
