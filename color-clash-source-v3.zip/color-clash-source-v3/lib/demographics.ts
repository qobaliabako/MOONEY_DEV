/** Optional self-reported descriptors, collected only after the timed task. */
export const AGE_OPTIONS = [
  {value:'18-24',label:'18–24'}, {value:'25-34',label:'25–34'},
  {value:'35-44',label:'35–44'}, {value:'45-54',label:'45–54'},
  {value:'55-64',label:'55–64'}, {value:'65+',label:'65+'},
  {value:'prefer_not_to_say',label:'Prefer not to say'},
] as const;
export const GENDER_OPTIONS = [
  {value:'woman',label:'Woman'}, {value:'man',label:'Man'},
  {value:'non_binary',label:'Non-binary'},
  {value:'another_term',label:'I describe my gender differently'},
  {value:'prefer_not_to_say',label:'Prefer not to say'},
] as const;
export type Demographics = {
  age_group:typeof AGE_OPTIONS[number]['value']|null;
  gender:typeof GENDER_OPTIONS[number]['value']|null;
};
/** Missing is distinct from explicitly declining; never infer either descriptor. */
export function cleanDemographics(input:unknown):Demographics {
  if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid demographics');
  const d=input as Record<string,unknown>;
  if(Object.keys(d).some(k=>!['age_group','gender'].includes(k)))throw Error('Unexpected demographics field');
  if(d.age_group!==null&&!AGE_OPTIONS.some(o=>o.value===d.age_group))throw Error('Invalid age group');
  if(d.gender!==null&&!GENDER_OPTIONS.some(o=>o.value===d.gender))throw Error('Invalid gender option');
  return {age_group:d.age_group,gender:d.gender} as Demographics;
}
