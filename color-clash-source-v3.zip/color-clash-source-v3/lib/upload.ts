'use client';
import type {Mode,ResponseRow} from './task';
import type {Demographics} from './demographics';
export const DRAFT_KEY='color-clash-pending-v04',RECEIPT_KEY='color-clash-receipt-v04';
export type Draft={clientId:string,token:string,mode:Mode,appVersion?:string,knowledge:string,id?:string,seed?:number,metadata:Record<string,unknown>,rows:ResponseRow[],ack:number,terminal?:string,survey?:unknown[],demographics?:Demographics};
export function readDraft():Draft|null{try{return JSON.parse(localStorage.getItem(DRAFT_KEY)||'null');}catch{return null;}}
export function writeDraft(d:Draft){localStorage.setItem(DRAFT_KEY,JSON.stringify(d));}
export class Uploader{
 pending:Promise<void>|null=null;
 constructor(public draft:Draft){}
 async request(body:unknown){const r=await fetch('/api/sessions/'+this.draft.id,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+this.draft.token},body:JSON.stringify(body)});const result=await r.json() as {error?:string,acknowledged:number,status:string};if(!r.ok)throw Error(result.error||'Saving unavailable');return result;}
 async reserve(){const d=this.draft;const r=await fetch('/api/sessions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...d,consent:true,adult:true,understands:true,metadata:d.metadata,rows:undefined,ack:undefined})});const result=await r.json() as {error?:string,id:string,seed:number};if(!r.ok)throw Error(result.error||'Unable to connect');if(typeof result.id!=='string'||!Number.isInteger(result.seed))throw Error('Invalid session receipt');d.id=result.id;d.seed=result.seed;writeDraft(d);return result;}
 record(row:ResponseRow){this.draft.rows.push(row);writeDraft(this.draft);if(this.draft.rows.length-this.draft.ack>=10)void this.flush().catch(()=>{});}
 async flush():Promise<void>{if(this.pending){await this.pending;return this.flush();}const work=async()=>{if(!this.draft.id)await this.reserve();while(this.draft.ack<this.draft.rows.length){const result=await this.request({action:'trials',rows:this.draft.rows.slice(this.draft.ack,this.draft.ack+20)});if(!Number.isInteger(result.acknowledged)||result.acknowledged<=this.draft.ack||result.acknowledged>this.draft.rows.length)throw Error('Invalid server acknowledgement');this.draft.ack=result.acknowledged;writeDraft(this.draft);}};this.pending=work();try{await this.pending;}finally{this.pending=null;}}
 async finalize(status:string,survey?:unknown[],demographics?:Demographics){this.draft.terminal=status;if(survey)this.draft.survey=survey;if(demographics)this.draft.demographics=demographics;writeDraft(this.draft);await this.flush();const result=await this.request({action:'finish',status});if(this.draft.survey)await this.request({action:'survey',responses:this.draft.survey});if(this.draft.demographics)await this.request({action:'demographics',demographics:this.draft.demographics});localStorage.setItem(RECEIPT_KEY,JSON.stringify({id:this.draft.id,token:this.draft.token,status:result.status}));localStorage.removeItem(DRAFT_KEY);return result;}
}
