# Browser adaptation note — 6 October 2026

The existing exploratory research question and primary analysis remain: do changes to some word–colour associations affect the contingency benefit for unchanged words differently in context A versus stable context B? This browser implementation is version 0.4.0-web, developed after the informed desktop personal pilot was inspected. It is not an externally registered preregistration or an ethics approval.

## Preserved design

Six neutral measured words, three colours and two outlines; 480 measured trials in four hidden 120-trial balancing chunks. No screen, quiz, feedback or break at trial 240. Conditional colour counts remain 8/1/1 for every word/context/chunk. Halfway through, three changeable words reverse cyclically in A only. Both outlines retain the same unchanged words and target-colour marginals. Seeded measured and practice schedules use a checked Python-compatible generator. Colour-to-key mapping is red/D, blue/F, green/J. Research practice uses separate words NEVA/PIMO/TULU, 36 trials per attempt, feedback, at least 80% valid correct responses, at most two attempts. The classic demonstration modes remain separate.

Nominal fixation 500 ms; response deadline 3 s; blank interval 400 ms. Practice feedback adds 700 ms. Fixed intervals are rounded to estimated frame periods. The first eligible key event ends the trial, even if wrong or below 200 ms. Later correct responses do not replace it. Correct responses at least 200 ms enter RT summaries. Timeouts have missing RT, not zero. All measured trials enter descriptive accuracy.

For unchanged words, compute each context/half’s C = median(infrequent correct usable RT) − median(frequent correct usable RT). S = (C_A,post − C_A,pre) − (C_B,post − C_B,pre). Negative S corresponds to the proposed relative reduction in A. Each primary cell has 48 frequent and 12 infrequent programmed trials before exclusions. Only complete full research tasks with estimable cells receive S. Negative/zero effects are retained. No extra trimming, post hoc window selection, sign-based exclusions, p-values or individual mechanism winners are introduced. A missing positive initial benefit limits spillover interpretation but is not an automatic person exclusion.

Four retrospective questions and twelve end-colour guesses precede the debrief. They do not establish awareness at the midpoint. Final question completion is tracked separately from timed-task completion.

## Browser-specific measurement and collection

Canvas geometry is expressed relative to viewport height, matching the desktop text/outline proportions and RGB values. Physical geometry and colour output are not calibrated. Drawing on requestAnimationFrame estimates onset/offset; KeyboardEvent.timeStamp estimates key time. Neither is a photodiode/response-box measurement. Refresh estimates, long-frame counts, display size, pixel ratio, browser/OS user agent and held-key waits are recorded. Synthetic/untrusted key events are ignored in the task; this does not prove that every public client is a genuine human.

Switching away, losing fullscreen when it was entered, or changing viewport geometry stops the active task rather than resuming after a context break. Previously completed responses remain as a partial session; interrupted trials are not replayed. A refresh supports retry of saved uploads, not continuation of the measured sequence. Missing surveys do not invalidate complete timed data.

IDs refer to sessions and are allocated automatically per mode. Pseudonymous responses are sent to server storage after affirmative participation information; participant names and nationality are not requested. Public participants can write only with their own secret session token; raw reads/exports require organiser sign-in and authorization. Sessions may be withdrawn from the same browser. ID numbers remain allocated after withdrawal. Withdrawing cannot retrospectively erase copies already exported by the organiser; handle those by code through the organiser.

The previous desktop pilot remains informed and separate. First-session browser participants, informed tests, incomplete sessions and repeats must be reported separately. Browser and desktop summaries must not be pooled simply because trial design matches. Before collection, record the convenience target and stopping date, using actual completion/exclusion counts and a stopping rule independent of results.

No nationality analysis is planned. A future cross-cultural study would need a specific construct, planned groups, suitable recruitment and controls for language, education and device/context differences. This pilot measures behaviour, not neuronal firing, synaptic activity or neurotransmitters.

## Amendment: optional demographics, 7 October 2026

Version 0.4.1-web adds optional adult age bands (18–24, 25–34, 35–44, 45–54, 55–64, 65+) and self-described gender (woman, man, non-binary, describes differently). Both include prefer-not-to-say and may be skipped. They appear after timed trials and any awareness questions; no stimulus schedule, primary contrast, or RT scoring changes. The purpose is sample description. No demographic hypothesis or subgroup comparison is introduced. Report category counts and missingness without identifying rare combinations; keep participants with missing demographics in the behavioural analysis if they otherwise meet its criteria. Older or already-running 0.4.0-web sessions may lack these fields. This is a documented exploratory protocol amendment, not a retroactive preregistration.
