# Color Clash

A browser-based colour-response experiment with automatic data collection and a private researcher dashboard.

[Live experiment](https://color-clash-bako.djane2020.chatgpt.site/) · [Researcher sign-in](https://color-clash-bako.djane2020.chatgpt.site/research) · [Scientific protocol](PROTOCOL_WEB.md)

Participants respond to the ink colour using a physical keyboard. The main research task uses learned word–colour associations and outline contexts. Separate demonstration and classic Stroop pilot modes are also included. Participation does not require an account.

This repository contains the application source from **Site version 3**, commit `bb49172c9b1bd4a53a3bc731d007bae223ac770a`. The scientific protocol remains `0.4.1-web`. This GitHub export adds documentation while preserving the application code, dependencies, tests and migrations from that version.

## Features

- Seeded trial schedules with verification against independently generated Python fixtures.
- Canvas-based stimulus presentation, keyboard responses, reaction-time measurements and interruption diagnostics.
- A main task with 480 measured trials, 36 practice trials per attempt, an optional 16-question questionnaire, and optional age-band/gender descriptors.
- Automatic session numbering and uploads, with idempotent retries and recovery of buffered responses.
- Server-side schedule, response-order and completion validation.
- ChatGPT researcher sign-in with an owner allowlist enforced at every researcher endpoint.
- Individual CSV/JSON downloads and a complete ZIP containing session summaries, combined trial rows, per-session JSON and a README.
- Reversible exclusion from analysis, with reasons, timestamps and ordered history; raw exports retain excluded sessions.
- Confirmed permanent deletion, with minimal tombstones that block upload retries while preserving participant counters.
- Additive database migrations and isolated destructive tests.

## Technology

TypeScript, React 19, Next.js-compatible App Router APIs, Vinext/Vite, Tailwind CSS, Radix UI, Cloudflare Workers, Cloudflare D1 (SQLite), Drizzle schema/migrations, Zod, and Miniflare integration tests.

Vinext builds the server application for Cloudflare Workers. GitHub hosts the **source repository**; GitHub Pages alone cannot run the database, researcher authentication or server endpoints.

## Where the code is

| File or directory | Purpose |
| --- | --- |
| [`app/experiment.tsx`](app/experiment.tsx) | Participant flow and experiment interface |
| [`lib/task.ts`](lib/task.ts) | Seeded schedules, scoring and descriptive summaries |
| [`lib/engine.ts`](lib/engine.ts) | Canvas presentation, input and timing diagnostics |
| [`lib/upload.ts`](lib/upload.ts) | Buffered uploads and retry handling |
| [`app/api/sessions/`](app/api/sessions/) | Session reservation and participant upload endpoints |
| [`app/research/`](app/research/) | Researcher sign-in and dashboard |
| [`app/api/research/`](app/api/research/) | Protected exports, exclusion and deletion endpoints |
| [`lib/research.ts`](lib/research.ts) | Research records, exports and data-management operations |
| [`lib/zip.ts`](lib/zip.ts) | Streaming ZIP writer |
| [`db/schema.ts`](db/schema.ts), [`drizzle/`](drizzle/) | Schema and append-only database migrations |
| [`tests/`](tests/) | Schedule, timing, upload and database integration tests |

## Run locally

Use Node.js **22.13 or newer** and pnpm. The package-manager version is recorded in `package.json`; dependencies are locked in `pnpm-lock.yaml`.

```sh
pnpm install --frozen-lockfile
```

Create a local `.dev.vars` file containing the following **development-only** value. The local Sites sign-in simulator uses this identity:

```dotenv
RESEARCH_OWNER_EMAIL=seedy@sites.test
```

Build once to generate the local Worker configuration:

```sh
pnpm build
```

For a **fresh local test database**, apply the existing migrations in order:

```sh
pnpm exec wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_married_silver_sable.sql
pnpm exec wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_peaceful_killmonger.sql
pnpm exec wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0002_common_sway.sql
pnpm dev
```

Open the local URL printed by the server, normally `http://127.0.0.1:5173/`. The local sign-in simulator is separate from the hosted ChatGPT authentication flow. Do not reapply these setup migrations to an already-initialized database.

The `install:ci` script comes from the Linux Sites environment; direct `pnpm install --frozen-lockfile` is the portable installation command.

## Run checks

```sh
pnpm exec tsc --noEmit --incremental false
node --experimental-strip-types tests/verification.mjs
node tests/upload.mjs
node tests/research.mjs
```

`tests/research.mjs` creates its own ephemeral local D1 database and temporary files under `.sites-runtime/`. It verifies authorization, complete exports, questionnaires/demographics, reversible exclusions, confirmed deletion, retry blocking and preservation of existing records/counters. It does not use the live database.

Additional checks from the original project:

```sh
node --experimental-strip-types tests/engine.mjs
pnpm build
node --experimental-strip-types tests/server.mjs
```

Run `tests/research.mjs` first so `.sites-runtime/` exists for the engine test. The server test uses the built Worker and its own test database. All generated fixtures are synthetic.

## Hosting and authentication

The live application is hosted with Sites on Cloudflare Workers and D1. Its `.openai/hosting.json` contains the existing public project identifier and logical database binding, not credentials or database contents.

Production researcher access depends on the Sites dispatcher validating ChatGPT authentication and supplying trusted identity headers. Copying the app to another host requires an equivalent trusted authentication boundary; client-supplied headers are not authentication. `RESEARCH_OWNER_EMAIL` belongs in the production secret store, never in source control.

## Data and scientific scope

No participant records, production databases, authentication tokens, runtime secrets or local development databases are included in this repository. The test fixtures are generated schedules and synthetic test records. `.gitignore` excludes environment files, databases in runtime folders, build output and installed dependencies.

This is an educational, exploratory behavioural project. Browser event timestamps and animation frames are not externally calibrated physical display or keypress measurements. Descriptive results do not establish a diagnosis or a neural mechanism. Read [PROTOCOL_WEB.md](PROTOCOL_WEB.md) for the scientific design, scoring and interpretation boundaries.

The original project README is retained at [docs/ORIGINAL_README.md](docs/ORIGINAL_README.md) as historical documentation; some verification notes there predate version 3. File hashes and source provenance are in [docs/SOURCE_VERSION.json](docs/SOURCE_VERSION.json).

## Portfolio and GitHub

See [docs/PORTFOLIO.md](docs/PORTFOLIO.md) for a repository description, CV wording and upload instructions. This project was developed with AI assistance.

## License

[MIT](LICENSE). Existing dependency and vendored-component license notices are retained.
