// Independent Python fixtures verify schedule parity; no human data are used.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {makeTask,makePractice,score,summarize} from '../lib/task.ts';
const fixtures=JSON.parse(fs.readFileSync(new URL('./desktop-fixtures.json',import.meta.url),'utf8'));
for(const f of fixtures){assert.deepEqual(makeTask(f.mode,f.seed),f.task);for(let i=1;i<=2;i++)assert.deepEqual(await makePractice(f.mode,f.seed,i),f.practice[i-1]);}
assert.equal(score(makeTask('research',42)[0],'',null).timeout,1);
assert.equal(score(makeTask('research',42)[0],makeTask('research',42)[0].correct_key,.1).rt_usable,0);
assert.equal(summarize([],'research_check').spillover_ms,null);
console.log('PASS: 12 measured schedules + 24 practice schedules exactly match Python; response eligibility and technical-mode inference guards checked.');
