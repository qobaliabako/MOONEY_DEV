// Mock frame-clock verification; no browser or physical-timing claim.
import assert from 'node:assert/strict';import fs from 'node:fs';import ts from 'typescript';
import {makeTask} from '../lib/task.ts';
const source=fs.readFileSync('lib/engine.ts','utf8').replace("from './task'","from '../lib/task.ts'");
fs.writeFileSync('.sites-runtime/engine-test.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
let time=0,shown=null,onset=null,events=[];const listeners=new Map();
globalThis.innerWidth=1280;globalThis.innerHeight=800;globalThis.devicePixelRatio=1;
Object.defineProperty(globalThis,'performance',{configurable:true,value:{now:()=>time,timeOrigin:0}});
globalThis.window={addEventListener(name,f){listeners.set(name,f);}};
globalThis.document={addEventListener(){},hidden:false,fullscreenElement:null};
globalThis.requestAnimationFrame=cb=>setImmediate(()=>{time+=1000/60;if(onset!==null){for(const e of events.filter(e=>!e.sent&&time>=onset+e.rt)){e.sent=true;listeners.get('keydown')?.({key:e.key,timeStamp:onset+e.rt,isTrusted:true,repeat:false,preventDefault(){}});listeners.get('keyup')?.({key:e.key});}}cb(time);});
const ctx={scale(){},fillRect(){shown=null;},fillText(text){shown=text;if(text==='DAXI'||text==='FENU'||text==='GOPA'||text==='HESI'||text==='JONU'||text==='KAVO')onset=time;},beginPath(){},arc(){},rect(){},stroke(){}};
const canvas={style:{},getContext:()=>ctx};const {Engine,Interrupted}=await import('../.sites-runtime/engine-test.mjs');
const t=makeTask('research',42)[0];
async function trial(responses){time=0;onset=null;events=responses.map(e=>({...e,sent:false}));const engine=new Engine(canvas,1000/60,['d','f','j'],false);try{return await engine.trial(t,0,false);}finally{engine.cleanup();}}
const normal=await trial([{key:t.correct_key,rt:500}]);assert.equal(normal.rt_s,.5);assert.equal(normal.rt_usable,1);assert.ok(normal.offset_s>=normal.onset_s+.5);
const early=await trial([{key:t.correct_key,rt:100},{key:t.correct_key,rt:500}]);assert.equal(early.rt_s,.1);assert.equal(early.anticipatory,1);assert.equal(early.rt_usable,0);
const wrongKey=['d','f','j'].find(k=>k!==t.correct_key);const wrong=await trial([{key:wrongKey,rt:300},{key:t.correct_key,rt:500}]);assert.equal(wrong.response_key,wrongKey);assert.equal(wrong.correct,0);
const timeout=await trial([]);assert.equal(timeout.rt_s,null);assert.equal(timeout.timeout,1);assert.ok(timeout.offset_s-timeout.onset_s>=3);
const late=await trial([{key:t.correct_key,rt:3100}]);assert.equal(late.timeout,1);
const engine=new Engine(canvas,1000/60,['d','f','j'],false);engine.stop('interrupted');await assert.rejects(engine.trial(t,0,false),Interrupted);engine.cleanup();
console.log('PASS: mock-frame first response, wrong-first, anticipatory eligibility, timeout, late response and interruption semantics. Physical timing not tested.');
