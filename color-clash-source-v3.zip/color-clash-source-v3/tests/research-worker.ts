// Test-only entrypoint. Never imported by the application or its build.
import {GET as research} from '../app/api/research/route';
import {POST as manage} from '../app/api/research/manage/route';
import {POST as reserve} from '../app/api/sessions/route';
import {POST as upload} from '../app/api/sessions/[id]/route';
import {authorize,append,finish} from '../lib/session';
import {deleteSessions} from '../lib/research';
export default {async fetch(request:Request){
 const path=new URL(request.url).pathname;
 if(path==='/api/research')return research(request);
 if(path==='/api/research/manage')return manage(request);
 if(path==='/api/sessions')return reserve(request);
 if(path.startsWith('/api/sessions/'))return upload(request,{params:Promise.resolve({id:path.split('/').pop()!})});
 if(path==='/test/stale-upload'){
  const b=await request.json() as {id:string,token:string,rows:Record<string,unknown>[]};const s=await authorize(b.id,b.token);await deleteSessions([s.id]);
  try{await append(s,b.rows);await finish(s,'aborted');return Response.json({restored:true});}catch{return Response.json({restored:false});}
 }
 return new Response('Not found',{status:404});
}};
