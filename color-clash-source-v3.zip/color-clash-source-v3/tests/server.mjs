/** Disposable Miniflare integration tests, outside production. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {makeTask,makePractice,score,CUES,VERSION} from '../lib/task.ts';
const require=createRequire(import.meta.url);const workerRequire=createRequire(require.resolve('wrangler'));const {Miniflare}=workerRequire('miniflare');
const owner='owner@color-clash.test';
const modules=[{type:'ESModule',path:resolve('dist/server/index.js')},...fs.readdirSync('dist/server',{recursive:true}).filter(p=>p.endsWith('.js')&&p!=='index.js').map(p=>({type:'ESModule',path:resolve('dist/server',p)}))];
const mf=new Miniflare({modules,modulesRoot:resolve('dist/server'),compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'test-color-clash'},bindings:{RESEARCH_OWNER_EMAIL:owner}});
const origin='http://color-clash.test';const ownerHeaders={'oai-authenticated-user-id':'test-owner','oai-authenticated-user-email':owner};
const metadata={user_agent:'SYNTHETIC INTEGRATION TEST',width:1280,height:800,pixel_ratio:1,refresh_hz:60,refresh_stable:true,fullscreen:true,time_origin:1};
function spec(mode='research'){return {clientId:crypto.randomUUID(),token:crypto.randomBytes?crypto.randomBytes(32).toString('hex'):[...crypto.getRandomValues(new Uint8Array(32))].map(x=>x.toString(16).padStart(2,'0')).join(''),mode,appVersion:VERSION,knowledge:'technical/informed',consent:true,adult:true,understands:true,test:true,metadata};}
async function post(path,data,token='',extra={}){const r=await mf.dispatchFetch(origin+path,{method:'POST',headers:{origin,'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...extra},body:JSON.stringify(data)});const text=await r.text();if(!text.startsWith('{'))throw Error(`${path} returned ${r.status}: ${text.slice(0,500)}`);return {status:r.status,data:JSON.parse(text)};}
function row(t,seq){const onset=10+seq*2;return {...t,seq,...score(t,t.correct_key,.5),onset_s:onset,offset_s:onset+.51,frame_interval_count:31,long_frame_count:0,max_frame_interval_s:1/60,visibility_interrupted:0,fullscreen_lost:0,viewport_changed:0,held_key_wait_s:0,synthetic_event_count:0};}
try{
 const db=await mf.getD1Database('DB');for(const migration of fs.readdirSync('drizzle').filter(p=>p.endsWith('.sql')).sort())for(const sql of fs.readFileSync('drizzle/'+migration,'utf8').split('--> statement-breakpoint').filter(x=>x.trim()))await db.prepare(sql).run();
 const specs=Array.from({length:12},()=>spec());const reservations=await Promise.all(specs.map(s=>post('/api/sessions',s,'',ownerHeaders)));
 assert.ok(reservations.every(x=>x.status===201&&x.data.version===VERSION));assert.equal(new Set(reservations.map(x=>x.data.id)).size,12);
 assert.deepEqual(reservations.map(x=>Number(x.data.id.split('_P')[1])).sort((a,b)=>a-b),Array.from({length:12},(_,i)=>i+1));
 const s=specs[0],reserved=reservations[0].data;
 const repeats=await Promise.all(Array.from({length:8},()=>post('/api/sessions',s,'',ownerHeaders)));assert.ok(repeats.every(x=>x.data.id===reserved.id&&x.data.seed===reserved.seed));
 const duplicateSpec=spec('demo');const duplicate=await Promise.all(Array.from({length:8},()=>post('/api/sessions',duplicateSpec,'',ownerHeaders)));assert.equal(new Set(duplicate.map(x=>x.data.id)).size,1);assert.equal(duplicate[0].data.id,'demo_P001');
 assert.equal((await mf.dispatchFetch(origin+'/api/research')).status,403);
 assert.equal((await mf.dispatchFetch(origin+'/api/research',{headers:{...ownerHeaders,'oai-authenticated-user-email':'outsider@test'}})).status,403);
 const path='/api/sessions/'+reserved.id;assert.equal((await post(path,{action:'demographics',demographics:{age_group:'18-24',gender:'woman'}},s.token)).status,409);assert.equal((await post(path,{action:'finish',status:'completed'},s.token)).status,409);
 assert.equal((await post(path,{action:'trials',rows:[row(makeTask('research',reserved.seed)[0],0)]},s.token)).status,409);
 assert.equal((await post(path,{action:'trials',rows:[]},'0'.repeat(64))).status,403);
 const practice=await makePractice('research',reserved.seed,1),task=makeTask('research',reserved.seed),all=[...practice,...task].map(row);
 let ack=await post(path,{action:'trials',rows:all.slice(0,10)},s.token);assert.equal(ack.data.acknowledged,10);
 assert.equal((await post(path,{action:'trials',rows:all.slice(0,10)},s.token)).data.acknowledged,10);
 assert.equal((await post(path,{action:'trials',rows:[{...all[0],rt_s:.6}]},s.token)).status,409);
 for(let i=10;i<all.length;i+=20){const a=await post(path,{action:'trials',rows:all.slice(i,i+20)},s.token);assert.equal(a.status,200);}
 const done=await post(path,{action:'finish',status:'completed'},s.token);assert.equal(done.status,200);assert.equal(done.data.summary.n_task,480);assert.equal(done.data.summary.spillover_ms,0);
 const responses=['noticed_associations','noticed_change','used_words','interruption'].map(question=>({question,answer:'no'}));for(const context of ['A','B'])for(const cue of CUES)responses.push({question:'end_colour_estimate',cue,context,frame:task.find(t=>t.cue===cue&&t.context===context).frame,answer:'unsure / prefer not to answer'});
 assert.equal((await post(path,{action:'survey',responses},s.token)).status,200);
 const legacyExport=await mf.dispatchFetch(origin+'/api/research?id='+reserved.id,{headers:ownerHeaders});assert.equal((await legacyExport.json()).demographics,null);
 assert.equal((await post(path,{action:'demographics',demographics:{age_group:'under_18',gender:'woman'}},s.token)).status,409);
 assert.equal((await post(path,{action:'demographics',demographics:{age_group:'18-24',gender:'not_a_category'}},s.token)).status,409);
 assert.equal((await post(path,{action:'demographics',demographics:{age_group:'18-24',gender:'woman',date_of_birth:'2000-01-01'}},s.token)).status,409);
 assert.equal((await post(path,{action:'demographics',demographics:{age_group:null,gender:null}},'0'.repeat(64))).status,403);
 for(const demographics of [{age_group:null,gender:null},{age_group:null,gender:'prefer_not_to_say'},{age_group:'18-24',gender:'woman'},{age_group:'18-24',gender:'woman'}])assert.equal((await post(path,{action:'demographics',demographics},s.token)).status,200);
 const exported=await mf.dispatchFetch(origin+'/api/research?id='+reserved.id,{headers:ownerHeaders});const data=await exported.json();assert.equal(data.trials.length,516);assert.equal(data.survey.length,16);assert.deepEqual(data.demographics,{age_group:'18-24',gender:'woman'});assert.equal(data.metadata.data_kind,'synthetic_test');assert.ok(!('token_hash' in data));assert.ok(exported.headers.get('content-disposition').includes(reserved.id+'.json'));
 const csv=await mf.dispatchFetch(origin+'/api/research?id='+reserved.id+'&format=csv',{headers:ownerHeaders});assert.equal(csv.status,200);const lines=(await csv.text()).trim().split('\n');assert.equal(lines.length,517);assert.ok(lines[0].includes('"demographics_submitted","age_group","gender"'));assert.ok(lines[1].includes('"1","18-24","woman"'));assert.ok(lines[0].startsWith('"session_id","mode","app_version","seed","data_kind","prior_task_knowledge",'));assert.ok(lines[1].startsWith('"'+reserved.id+'","research",'));assert.ok(csv.headers.get('content-disposition').includes(reserved.id+'_trials.csv'));assert.equal((await mf.dispatchFetch(origin+'/api/research?id='+reserved.id+'&format=csv')).status,403);
 assert.equal((await post(path,{action:'withdraw'},s.token)).status,200);assert.equal((await db.prepare('SELECT demographics FROM sessions WHERE id = ?').bind(reserved.id).first()).demographics,null);assert.equal((await post(path,{action:'demographics',demographics:{age_group:'18-24',gender:'woman'}},s.token)).status,409);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM trials WHERE session_id = ?').bind(reserved.id).first()).n,0);
 assert.equal((await post(path,{action:'trials',rows:[all[0]]},s.token)).status,409);
 const next=await post('/api/sessions',spec(),' ',ownerHeaders);assert.equal(next.data.id,'research_P013');
 const oldClient=spec('experiment');delete oldClient.appVersion;const oldReservation=await post('/api/sessions',oldClient,'',ownerHeaders);assert.equal(oldReservation.status,201);assert.equal(oldReservation.data.version,'0.4.0-web');assert.equal((await post('/api/sessions',{...oldClient,appVersion:VERSION},'',ownerHeaders)).data.version,'0.4.0-web');
 console.log('PASS: concurrent mode IDs, simultaneous idempotent reservations, incomplete-task guards, schedule/scoring validation, duplicate/conflicting uploads, full 516-row save, questionnaire, private JSON/CSV exports, optional/skipped/invalid demographics, retry and withdrawal. Synthetic test database only.');
}finally{await mf.dispose();}
