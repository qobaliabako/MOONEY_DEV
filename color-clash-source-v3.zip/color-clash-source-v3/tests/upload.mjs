/** Exercise the actual upload queue with a failed demographic upload and reload. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
fs.mkdirSync('.sites-runtime',{recursive:true});
const modulePath=resolve('.sites-runtime/upload-test.mjs');
fs.writeFileSync(modulePath,ts.transpileModule(fs.readFileSync('lib/upload.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
const {Uploader,readDraft,DRAFT_KEY,RECEIPT_KEY}=await import(pathToFileURL(modulePath).href);
const memory=new Map();
globalThis.localStorage={getItem:key=>memory.get(key)??null,setItem:(key,value)=>memory.set(key,value),removeItem:key=>memory.delete(key)};
const calls=[];let fail=true;
globalThis.fetch=async(url,options)=>{
 const body=JSON.parse(options.body);calls.push({url,body});
 if(body.action==='demographics'&&fail)return Response.json({error:'Temporary test outage'},{status:503});
 return Response.json({status:'completed',acknowledged:0});
};
const draft={clientId:'test-client',token:'test-token',mode:'research',id:'research_P777',seed:42,knowledge:'technical/informed',metadata:{},rows:[],ack:0};
const survey=[{question:'test',answer:'yes'}];const demographics={age_group:null,gender:'prefer_not_to_say'};
await assert.rejects(new Uploader(draft).finalize('completed',survey,demographics),/Temporary test outage/);
assert.deepEqual(readDraft().demographics,demographics);assert.deepEqual(readDraft().survey,survey);
assert.equal(localStorage.getItem(RECEIPT_KEY),null);
fail=false;const recovered=new Uploader(readDraft());await recovered.finalize('completed');
assert.ok(calls.every(c=>c.url==='/api/sessions/research_P777'));
assert.deepEqual(calls.slice(-3).map(c=>c.body.action),['finish','survey','demographics']);
assert.deepEqual(calls.at(-1).body.demographics,demographics);
assert.equal(localStorage.getItem(DRAFT_KEY),null);assert.equal(JSON.parse(localStorage.getItem(RECEIPT_KEY)).id,'research_P777');
// A pre-update draft with no demographic fields can still finish normally.
calls.length=0;await new Uploader({...draft,id:'research_P778',survey:undefined,demographics:undefined}).finalize('completed');
assert.deepEqual(calls.map(c=>c.body.action),['finish']);
console.log('PASS: demographic upload failure retains answers; reload retries the same session; receipt waits for acknowledgement; older drafts remain compatible. Mock network only.');
