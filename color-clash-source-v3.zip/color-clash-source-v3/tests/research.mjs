import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,mkdir,writeFile,readdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
const require=createRequire(import.meta.url);
const {build}=createRequire(require.resolve('vite/package.json'))('esbuild');
const {Miniflare}=createRequire(require.resolve('wrangler/package.json'))('miniflare');
const temp=resolve('.sites-runtime/research-tests');await mkdir(temp,{recursive:true});
await build({entryPoints:['tests/research-worker.ts'],outfile:temp+'/worker.mjs',bundle:true,format:'esm',platform:'browser',target:'es2022',external:['cloudflare:workers'],alias:{'@':resolve('.')},logLevel:'warning'});
await build({entryPoints:['lib/task.ts'],outfile:temp+'/task.mjs',bundle:true,format:'esm',platform:'node',target:'es2022',logLevel:'warning'});
const {makeTask,makePractice,score}=await import(temp+'/task.mjs');
// Ephemeral, local-only D1. No production ID, URL, token, or database is used.
const mf=new Miniflare({modules:true,scriptPath:temp+'/worker.mjs',compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:['DB'],bindings:{RESEARCH_OWNER_EMAIL:'owner@example.test'},d1Persist:false});
const db=await mf.getD1Database('DB');const passed=[];
const origin='https://test.local',owner={'oai-authenticated-user-id':'test-owner','oai-authenticated-user-email':'owner@example.test'},other={'oai-authenticated-user-id':'other','oai-authenticated-user-email':'other@example.test'};
async function req(path,body,auth=owner,extra={}){return mf.dispatchFetch(origin+path,{method:body===undefined?'GET':'POST',headers:{...auth,Origin:origin,...(body?{'Content-Type':'application/json'}:{}),...extra},...(body?{body:JSON.stringify(body)}:{})});}
async function json(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}
async function apply(name){const sql=await readFile('drizzle/'+name,'utf8');for(const stmt of sql.split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(stmt).run();}
async function snapshot(){return JSON.stringify(await Promise.all(['sessions','trials','mode_counters'].map(t=>db.prepare(`SELECT * FROM ${t} ORDER BY 1`).all())));}
const token='ab'.repeat(32),tokenHash=createHash('sha256').update(token).digest('hex');
function reservation(mode='research',clientId=randomUUID()){return {clientId,token,mode,appVersion:'0.4.1-web',knowledge:'technical/informed',consent:true,adult:true,understands:true,test:true,metadata:{user_agent:'Synthetic integration test',width:1200,height:800,pixel_ratio:1,refresh_hz:60,refresh_stable:true,fullscreen:true,time_origin:1000}};}
function responses(plan,start=0){return plan.map((t,i)=>({...t,seq:i+start,...score(t,t.correct_key,.4),onset_s:(i+start)*5+1,offset_s:(i+start)*5+1.4,frame_interval_count:24,long_frame_count:0,max_frame_interval_s:1/60,visibility_interrupted:0,fullscreen_lost:0,viewport_changed:0,held_key_wait_s:0,synthetic_event_count:0}));}
async function postSession(id,body){return req('/api/sessions/'+id,body,{}, {Authorization:'Bearer '+token});}
async function management(action,sessionIds,reason='Test decision'){return req('/api/research/manage',action==='delete'?{action,sessionIds,confirmed:true,confirmation:'PERMANENTLY DELETE SELECTED SESSIONS'}:{action,sessionIds,reason});}
function unzip(buffer){const view=new DataView(buffer.buffer,buffer.byteOffset,buffer.byteLength),end=buffer.length-22;assert.equal(view.getUint32(end,true),0x06054b50);const count=view.getUint16(end+10,true);let at=view.getUint32(end+16,true);const files=new Map();for(let i=0;i<count;i++){assert.equal(view.getUint32(at,true),0x02014b50);const size=view.getUint32(at+24,true),nameLength=view.getUint16(at+28,true),extra=view.getUint16(at+30,true),comment=view.getUint16(at+32,true),local=view.getUint32(at+42,true);const name=buffer.subarray(at+46,at+46+nameLength).toString();const start=local+30+view.getUint16(local+26,true)+view.getUint16(local+28,true);files.set(name,buffer.subarray(start,start+size).toString());at+=46+nameLength+extra+comment;}return files;}
try{
 await apply('0000_married_silver_sable.sql');await apply('0001_peaceful_killmonger.sql');
 await db.batch([
  db.prepare('INSERT INTO mode_counters VALUES (?,?)').bind('research_check',7),
  db.prepare('INSERT INTO sessions (id,client_id,token_hash,mode,ordinal,seed,version,knowledge,status,started,updated,metadata,survey,demographics,summary,saved) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind('research_check_P007',randomUUID(),tokenHash,'research_check',7,123,'0.4.0-web','technical/informed','completed','2026-01-01','2026-01-01','{"data_kind":"synthetic_test"}',JSON.stringify([{question:'legacy',answer:'yes'}]),'{"age_group":"25-34","gender":"woman"}','{"n_task":1,"spillover_ms":null}',1),
  db.prepare('INSERT INTO trials VALUES (?,?,?,?,?)').bind('research_check_P007',0,'legacy-trial','{"trial_id":"legacy-trial","seq":0,"rt_s":0.4}', 'old-hash')
 ]);
 // Compare research values rather than timing/metadata returned by D1.
 const before=(await db.prepare('SELECT * FROM sessions').all()).results;
 const beforeTrials=(await db.prepare('SELECT * FROM trials').all()).results;
 await apply('0002_common_sway.sql');
 assert.deepEqual((await db.prepare('SELECT * FROM sessions').all()).results,before);assert.deepEqual((await db.prepare('SELECT * FROM trials').all()).results,beforeTrials);assert.equal((await db.prepare('SELECT number FROM mode_counters').first()).number,7);passed.push('Additive migration preserves legacy records, demographics, questionnaires, trials and counters');
 for(const auth of [{},other,{'oai-authenticated-user-email':'owner@example.test'},{'oai-authenticated-user-id':'test-owner'}]){
  for(const path of ['/api/research','/api/research?id=research_check_P007','/api/research?id=research_check_P007&format=csv','/api/research?download=all'])await json(await req(path,undefined,auth),403);
  for(const action of ['delete','exclude','include'])await json(await req('/api/research/manage',{action,sessionIds:['research_check_P007'],reason:'Denied',confirmed:true,confirmation:'PERMANENTLY DELETE SELECTED SESSIONS'},auth),403);
 }
 await json(await req('/api/research/manage',{action:'exclude',sessionIds:['research_check_P007'],reason:'No'},owner,{Origin:'https://other.test'}),403);
 passed.push('All research endpoints reject anonymous, wrong-account, incomplete identity and cross-origin writes');
 const draft=reservation();const session=await json(await req('/api/sessions',draft,{}),201);assert.equal(session.id,'research_P001');
 const replay=await json(await req('/api/sessions',draft,{}));assert.equal(replay.id,session.id);assert.equal((await db.prepare("SELECT number FROM mode_counters WHERE mode='research'").first()).number,1);
 const plan=[...await makePractice('research',session.seed,1),...makeTask('research',session.seed)],rows=responses(plan);
 for(let i=0;i<rows.length;i+=20)await json(await postSession(session.id,{action:'trials',rows:rows.slice(i,i+20)}));
 await json(await postSession(session.id,{action:'trials',rows:rows.slice(-10)}));
 await json(await postSession(session.id,{action:'finish',status:'completed'}));
 const survey=['noticed_associations','noticed_change','used_words','interruption'].map(question=>({question,answer:'yes'}));
 for(const context of ['A','B'])for(const cue of ['DAXI','FENU','GOPA','HESI','JONU','KAVO'])survey.push({question:'end_colour_estimate',cue,context,frame:plan.find(t=>t.context===context&&t.cue===cue).frame,answer:'red'});
 const demographics={age_group:'35-44',gender:'non_binary'};
 await json(await postSession(session.id,{action:'survey',responses:survey}));await json(await postSession(session.id,{action:'demographics',demographics}));
 const record=await json(await req('/api/research?id='+session.id));assert.equal(record.trials.length,rows.length);assert.deepEqual(record.survey,survey);assert.deepEqual(record.demographics,demographics);
 const serialized=JSON.stringify(record);for(const secret of [token,tokenHash,draft.clientId,'token_hash','client_id'])assert(!serialized.includes(secret));
 const csv=await (await req('/api/research?id='+session.id+'&format=csv')).text();assert(csv.includes('"cue_set"'));assert(csv.includes('"non_binary"'));assert.equal(csv.trim().split('\r\n').length,rows.length+1);
 passed.push('Anonymous participant reservation, idempotent uploads, completion, all 16 answers and demographics preserved; individual CSV/JSON contain no credentials');
 const unchanged=(await db.prepare('SELECT * FROM sessions WHERE id=?').bind(session.id).first());
 await json(await req('/api/research/manage',{action:'exclude',sessionIds:[session.id],reason:'  '}),400);
 await json(await management('exclude',[session.id],'=requires review, "timing"'));
 const excluded=await json(await req('/api/research?id='+session.id));assert.equal(excluded.excluded_from_analysis,true);assert.equal(excluded.exclusion_history.length,1);assert.match(excluded.exclusion_changed_at,/Z$/);assert.deepEqual(excluded.trials,record.trials);assert.deepEqual(excluded.survey,record.survey);
 assert.deepEqual(await db.prepare('SELECT * FROM sessions WHERE id=?').bind(session.id).first(),unchanged);
 await json(await management('include',[session.id],'Timing reviewed; retain'));
 const restored=await json(await req('/api/research?id='+session.id));assert.equal(restored.excluded_from_analysis,false);assert.equal(restored.exclusion_history.length,2);assert.equal(restored.exclusion_history[0].excluded_from_analysis,true);assert.equal(restored.exclusion_history[1].excluded_from_analysis,false);
 await json(await management('exclude',[session.id],'=requires review, "timing"'));
 passed.push('Required reasons, UTC timestamps, reversible exclusion and ordered history without modifying original research data');
 // 505 extra stored sessions establish that export does not share the UI limit.
 for(let base=0;base<505;base+=50){await db.batch(Array.from({length:Math.min(50,505-base)},(_,i)=>{const n=base+i+1;return db.prepare('INSERT INTO sessions (id,client_id,token_hash,mode,ordinal,seed,version,knowledge,status,started,updated,metadata) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').bind('demo_P'+String(n).padStart(3,'0'),randomUUID(),tokenHash,'demo',n,n,'0.4.1-web','technical/informed',n===1?'withdrawn':'aborted','2026-02-01','2026-02-01','{"data_kind":"synthetic_test"}');}));}
 await db.prepare("INSERT INTO mode_counters VALUES ('demo',505)").run();
 const listing=await json(await req('/api/research'));assert.equal(listing.total,507);assert.equal(listing.sessions.length,500);
 const zipResponse=await req('/api/research?download=all');assert.equal(zipResponse.status,200);assert.equal(zipResponse.headers.get('content-type'),'application/zip');const zip=Buffer.from(await zipResponse.arrayBuffer());await writeFile(temp+'/all-results.zip',zip);const files=unzip(zip);
 assert.equal(files.size,510);assert(files.has('sessions/research_check_P007.json'));assert(files.has('sessions/demo_P001.json'));assert.equal(JSON.parse(files.get('sessions/'+session.id+'.json')).excluded_from_analysis,true);assert.deepEqual(JSON.parse(files.get('sessions/'+session.id+'.json')).survey,survey);
 assert.equal(files.get('session-summary.csv').trim().split('\r\n').length,508);assert.equal(files.get('combined-trials.csv').trim().split('\r\n').length,rows.length+2);assert(files.get('session-summary.csv').includes("'=requires review"));assert(files.get('README.txt').includes('Exclusion never removes data'));
 for(const [name,text] of files)for(const secret of [token,tokenHash,draft.clientId,'"token_hash"','"client_id"'])assert(!text.includes(secret),name+' contains a credential');
 passed.push('Valid all-results ZIP includes all 507 sessions beyond 500-row UI, excluded/withdrawn records, combined trials, full JSON, README and formula-safe CSV');
 const counters=(await db.prepare('SELECT * FROM mode_counters ORDER BY mode').all()).results;
 for(const body of [{action:'delete',sessionIds:[session.id]},{action:'delete',sessionIds:[session.id],confirmed:false,confirmation:'PERMANENTLY DELETE SELECTED SESSIONS'},{action:'delete',sessionIds:[session.id],confirmed:true}])await json(await req('/api/research/manage',body),400);
 assert(await db.prepare('SELECT id FROM sessions WHERE id=?').bind(session.id).first());
 await json(await management('delete',[session.id]));
 for(const [table,key] of [['sessions','id'],['trials','session_id'],['session_analysis','session_id'],['exclusion_history','session_id']])assert.equal((await db.prepare(`SELECT COUNT(*) AS n FROM ${table} WHERE ${key}=?`).bind(session.id).first()).n,0);
 const tombstone=await db.prepare('SELECT * FROM deleted_sessions WHERE id=?').bind(session.id).first();assert.deepEqual(Object.keys(tombstone).sort(),['client_id','deleted_at','id']);
 assert.deepEqual((await db.prepare('SELECT * FROM mode_counters ORDER BY mode').all()).results,counters);
 await json(await req('/api/sessions',draft,{}),410);
 for(const body of [{action:'trials',rows:rows.slice(0,20)},{action:'finish',status:'completed'},{action:'survey',responses:survey},{action:'demographics',demographics}])await json(await postSession(session.id,body),410);
 await json(await management('delete',[session.id]));await json(await req('/api/research?id='+session.id),404);
 const next=await json(await req('/api/sessions',reservation(),{}),201);assert.equal(next.id,'research_P002');
 assert.deepEqual(await db.prepare('SELECT * FROM sessions WHERE id=?').bind('research_check_P007').first(),before[0]);
 assert.deepEqual((await db.prepare('SELECT * FROM trials WHERE session_id=?').bind('research_check_P007').all()).results,beforeTrials);
 passed.push('Unconfirmed deletion rejected; confirmed deletion removes all research data; minimal tombstone blocks every retry; counters and unrelated legacy records preserved; next ID never reused');
 const raceDraft=reservation('research_check'),race=await json(await req('/api/sessions',raceDraft,{}),201);assert.equal(race.id,'research_check_P008');
 const stale=await json(await req('/test/stale-upload',{id:race.id,token,rows:responses(await makePractice('research_check',race.seed,1)).slice(0,1)}));assert.equal(stale.restored,false);assert.equal((await db.prepare('SELECT COUNT(*) AS n FROM trials WHERE session_id=?').bind(race.id).first()).n,0);
 await json(await req('/api/sessions',raceDraft,{}),410);assert.equal((await db.prepare("SELECT number FROM mode_counters WHERE mode='research_check'").first()).number,8);
 passed.push('Deletion wins over an upload that was already authorized; stale write cannot resurrect data or advance counters');
 console.log(JSON.stringify({passed:passed.length,checks:passed,test_database:'ephemeral local D1',production_writes:0},null,2));await writeFile(temp+'/report.json',JSON.stringify({passed:passed.length,checks:passed},null,2));
}finally{await mf.dispose();}
